package com.example.edukate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdukateApplicationTests {

    @Test
    void contextLoads() {
    }

}
