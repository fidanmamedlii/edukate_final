package com.example.edukate.dtos.departmentdto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DepartmentUpdateDto {
    private Long id;
    private String name;
}
