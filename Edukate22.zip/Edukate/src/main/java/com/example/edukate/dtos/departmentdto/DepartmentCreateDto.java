package com.example.edukate.dtos.departmentdto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DepartmentCreateDto {
    private String name;
}
