package com.example.edukate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdukateApplication {

    public static void main(String[] args) {
        var app = SpringApplication.run(EdukateApplication.class, args);
    }

}
