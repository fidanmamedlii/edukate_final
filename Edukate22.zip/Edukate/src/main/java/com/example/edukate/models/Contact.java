package com.example.edukate.models;

public class Contact {
}
