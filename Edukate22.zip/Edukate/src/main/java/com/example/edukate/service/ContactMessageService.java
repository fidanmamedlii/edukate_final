package com.example.edukate.service;


import com.example.edukate.dtos.replydto.ContactCommentDto;
import com.example.edukate.models.ContactMessage;

import java.util.List;

public interface ContactMessageService {
    public void saveMessage(ContactCommentDto message);
    public List<ContactMessage> getAllMessages();
    public ContactMessage replyToMessage(Long id, String reply);

}
