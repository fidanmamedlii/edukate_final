
package com.example.edukate.controller.Admin;

import com.example.edukate.dtos.replydto.ContactCommentDto;
import com.example.edukate.models.ContactMessage;
import com.example.edukate.repositories.ContactMessageRepository;
import com.example.edukate.service.ContactMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/messages")
public class ContactMessageAdminController {


    @Autowired
    private final ContactMessageRepository messageRepository;

    @Autowired
    private final JavaMailSender mailSender;
    @Autowired
    private final ContactMessageService messageService;

    public ContactMessageAdminController(ContactMessageRepository messageRepository, JavaMailSender mailSender, ContactMessageService messageService) {
        this.messageRepository = messageRepository;
        this.mailSender = mailSender;
        this.messageService = messageService;
    }

    @GetMapping
    public String getMessagesPage() {
        return "dashboard/replies/replies";
    }
    @PostMapping
    public String saveMessage(
            @ModelAttribute ContactCommentDto message) {


        messageService.saveMessage(message);
        return "redirect:/admin/messages";
    }


//    @GetMapping
//    public List<ContactMessage> getMessages() {
//        return messageService.getAllMessages();
//    }

    @PostMapping("/reply/{id}")
    public ContactMessage replyToMessage(@PathVariable Long id, @RequestBody String reply) {
        return messageService.replyToMessage(id, reply);
    }
}
