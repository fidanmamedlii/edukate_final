package com.example.edukate.controller;

import com.example.edukate.models.ContactForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ContactController {

    @Autowired
    private JavaMailSender mailSender;

    @GetMapping("/contact")
    public String showContactForm(Model model) {
        model.addAttribute("contactForm", new ContactForm());
        return "contact"; // Ensure this matches your Thymeleaf template name
    }

    @PostMapping("/contact")
    public String submitContactForm(@ModelAttribute ContactForm contactForm, Model model) {
        sendEmail(contactForm);
        model.addAttribute("message", "Your message has been sent successfully!");
        return "contact"; // Redirect to the same contact page or a success page
    }

    private void sendEmail(ContactForm contactForm) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("fidanmammadli28@gmail.com"); // Replace with your email address
        message.setTo("fidanmammadli28@gmail.com"); // Replace with your email address
        message.setSubject(contactForm.getSubject());
        message.setText("Name: " + contactForm.getName() + "\nEmail: " + contactForm.getEmail() + "\nMessage: " + contactForm.getMessage());

        mailSender.send(message);
    }
}
